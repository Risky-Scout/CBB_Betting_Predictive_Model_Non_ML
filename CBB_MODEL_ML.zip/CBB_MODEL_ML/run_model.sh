#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "========================================"
echo "CBB BETTING SYNDICATE v7.4"
echo "ML + CONTRARIAN + CLV"
echo "$(date)"
echo "========================================"

API_KEY="${1:-da45cdad6addfa18598c567d02ccd848}"

echo ""
echo "[1/4] Updating data..."
curl -s -o barttorvik_2026.csv "https://barttorvik.com/2026_team_results.csv"
python3 download_injuries.py 2>/dev/null

echo ""
echo "[2/4] Updating rebounding..."
python3 << 'PYEOF'
import requests, pandas as pd, os
url = "https://barttorvik.com/getadvstats.php?year=2026&csv=1"
r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=30)
lines = r.text.strip().split('\n')
team_reb = {}
for line in lines[1:]:
    parts, current, in_q = [], "", False
    for c in line:
        if c == '"': in_q = not in_q
        elif c == ',' and not in_q: parts.append(current.strip().strip('"')); current = ""
        else: current += c
    parts.append(current.strip().strip('"'))
    if len(parts) < 15: continue
    try:
        team, mpg = parts[1], float(parts[4]) if parts[4] else 0
        orb, drb = float(parts[9]) if parts[9] else 0, float(parts[10]) if parts[10] else 0
        if mpg < 10: continue
        if team not in team_reb: team_reb[team] = {'orb_sum': 0, 'drb_sum': 0, 'mpg_sum': 0}
        team_reb[team]['orb_sum'] += orb * mpg
        team_reb[team]['drb_sum'] += drb * mpg
        team_reb[team]['mpg_sum'] += mpg
    except: continue
stats = [{'team': t, 'orb_pct': round(s['orb_sum']/s['mpg_sum'], 1), 'drb_pct': round(s['drb_sum']/s['mpg_sum'], 1)} for t, s in team_reb.items() if s['mpg_sum'] > 0]
pd.DataFrame(stats).to_csv("team_rebounding.csv", index=False)
print(f"  ✓ {len(stats)} teams")
PYEOF

echo ""
echo "[3/4] Running model..."
python3 enhanced_betting_system_v7.py --odds-key "$API_KEY"

echo ""
echo "[4/4] Done!"
echo ""
echo "Commands:"
echo "  Results:  python3 enter_results.py"
echo "  CLV:      python3 clv_tracker.py report"
echo "  Public:   python3 public_betting.py entry"
