#!/usr/bin/env python3
"""
TRAVEL & TIMEZONE ADJUSTMENTS
=============================
West coast teams playing early = fatigue
Cross-country travel = disadvantage
"""

# Team locations (timezone)
TEAM_TIMEZONES = {
    # Pacific (PT)
    'gonzaga': 'PT', 'washington': 'PT', 'washington st.': 'PT', 'oregon': 'PT',
    'oregon st.': 'PT', 'stanford': 'PT', 'california': 'PT', 'usc': 'PT',
    'ucla': 'PT', 'san diego st.': 'PT', 'san diego': 'PT', 'santa clara': 'PT',
    'saint mary\'s': 'PT', 'san francisco': 'PT', 'pacific': 'PT', 'pepperdine': 'PT',
    'loyola marymount': 'PT', 'portland': 'PT', 'seattle': 'PT', 'byu': 'MT',
    'utah': 'MT', 'utah st.': 'MT', 'arizona': 'MT', 'arizona st.': 'MT',
    'colorado': 'MT', 'colorado st.': 'MT', 'air force': 'MT', 'new mexico': 'MT',
    'new mexico st.': 'MT', 'unlv': 'PT', 'nevada': 'PT', 'fresno st.': 'PT',
    'san jose st.': 'PT', 'boise st.': 'MT', 'wyoming': 'MT',
    
    # Mountain (MT)
    'denver': 'MT', 'northern colorado': 'MT', 'utah valley': 'MT',
    
    # Central (CT)
    'kansas': 'CT', 'kansas st.': 'CT', 'iowa st.': 'CT', 'oklahoma': 'CT',
    'oklahoma st.': 'CT', 'texas': 'CT', 'texas tech': 'CT', 'tcu': 'CT',
    'baylor': 'CT', 'houston': 'CT', 'smu': 'CT', 'rice': 'CT',
    'texas a&m': 'CT', 'arkansas': 'CT', 'lsu': 'CT', 'ole miss': 'CT',
    'mississippi st.': 'CT', 'alabama': 'CT', 'auburn': 'CT',
    'tennessee': 'CT', 'vanderbilt': 'CT', 'missouri': 'CT', 'iowa': 'CT',
    'minnesota': 'CT', 'wisconsin': 'CT', 'northwestern': 'CT', 'illinois': 'CT',
    'nebraska': 'CT', 'notre dame': 'CT', 'marquette': 'CT', 'depaul': 'CT',
    'loyola chicago': 'CT', 'butler': 'CT', 'xavier': 'CT', 'dayton': 'CT',
    'cincinnati': 'CT', 'memphis': 'CT', 'tulane': 'CT', 'ucf': 'CT',
    'south florida': 'CT', 'tulsa': 'CT', 'wichita st.': 'CT', 'creighton': 'CT',
    
    # Eastern (ET)
    'duke': 'ET', 'north carolina': 'ET', 'nc state': 'ET', 'wake forest': 'ET',
    'virginia': 'ET', 'virginia tech': 'ET', 'louisville': 'ET', 'kentucky': 'ET',
    'florida': 'ET', 'georgia': 'ET', 'south carolina': 'ET', 'clemson': 'ET',
    'georgia tech': 'ET', 'florida st.': 'ET', 'miami fl': 'ET', 'boston college': 'ET',
    'syracuse': 'ET', 'pittsburgh': 'ET', 'uconn': 'ET', 'connecticut': 'ET',
    'providence': 'ET', 'villanova': 'ET', 'st. john\'s': 'ET', 'seton hall': 'ET',
    'georgetown': 'ET', 'rutgers': 'ET', 'maryland': 'ET', 'penn st.': 'ET',
    'indiana': 'ET', 'purdue': 'ET', 'michigan': 'ET', 'michigan st.': 'ET',
    'ohio st.': 'ET', 'west virginia': 'ET',
}

# Timezone offsets from ET
TZ_OFFSET = {
    'ET': 0,
    'CT': -1,
    'MT': -2,
    'PT': -3,
}

def get_timezone(team):
    """Get team's timezone."""
    return TEAM_TIMEZONES.get(team.lower(), 'CT')  # Default to Central

def get_travel_adjustment(home_team, away_team, game_hour_et=19):
    """
    Calculate travel/timezone adjustment.
    
    Args:
        home_team: Home team name
        away_team: Away team name  
        game_hour_et: Game start time in ET (24-hour format)
    
    Returns:
        (adjustment, reason) - positive = favors home
    """
    home_tz = get_timezone(home_team)
    away_tz = get_timezone(away_team)
    
    home_offset = TZ_OFFSET.get(home_tz, 0)
    away_offset = TZ_OFFSET.get(away_tz, 0)
    
    tz_diff = abs(home_offset - away_offset)
    
    adj = 0.0
    reasons = []
    
    # Cross-country travel (3 timezone difference)
    if tz_diff >= 3:
        adj += 0.8  # Favors home
        reasons.append(f"Cross-country travel ({tz_diff} TZ)")
    elif tz_diff == 2:
        adj += 0.4
        reasons.append(f"Long travel ({tz_diff} TZ)")
    
    # West coast team playing early East coast game
    # Game at noon ET = 9 AM PT (body clock disadvantage)
    if away_tz == 'PT' and home_tz == 'ET' and game_hour_et < 14:
        adj += 0.6
        reasons.append("West coast early game")
    
    # East coast team playing late West coast game
    # Game at 10 PM ET = 7 PM PT (body clock = 1 AM)
    if away_tz == 'ET' and home_tz == 'PT' and game_hour_et >= 22:
        adj += 0.4
        reasons.append("East coast late game")
    
    reason = "; ".join(reasons) if reasons else ""
    return round(adj, 1), reason


if __name__ == "__main__":
    print("TRAVEL ADJUSTMENT TEST")
    print("="*60)
    
    tests = [
        ('Arizona St.', 'Colorado', 19),      # MT vs MT
        ('Duke', 'Gonzaga', 12),              # ET vs PT, noon game
        ('UCLA', 'Kentucky', 22),             # PT vs ET, late game
        ('Kansas', 'Texas', 19),              # CT vs CT
        ('Saint Mary\'s', 'Connecticut', 19), # PT vs ET
        ('Alabama', 'Oregon', 14),            # CT vs PT
    ]
    
    for home, away, hour in tests:
        adj, reason = get_travel_adjustment(home, away, hour)
        print(f"\n{away} @ {home} ({hour}:00 ET)")
        print(f"  Away TZ: {get_timezone(away)}, Home TZ: {get_timezone(home)}")
        print(f"  Adjustment: {adj:+.1f}")
        if reason:
            print(f"  Reason: {reason}")
