#!/usr/bin/env python3
"""
Download RotoWire injuries using Chrome cookies
"""
import os
import sqlite3
import shutil
import tempfile
import requests
from datetime import datetime

CSV_PATH = os.path.expanduser("~/cbb_betting/injuries.csv")

def get_chrome_cookies():
    """Extract cookies from Chrome"""
    cookie_path = os.path.expanduser("~/Library/Application Support/Google/Chrome/Default/Cookies")
    
    if not os.path.exists(cookie_path):
        print("Chrome cookies not found")
        return {}
    
    # Copy to temp file (Chrome locks the DB)
    tmp = tempfile.NamedTemporaryFile(delete=False)
    shutil.copy2(cookie_path, tmp.name)
    
    cookies = {}
    try:
        conn = sqlite3.connect(tmp.name)
        cursor = conn.cursor()
        cursor.execute("SELECT name, value FROM cookies WHERE host_key LIKE '%rotowire%'")
        for name, value in cursor.fetchall():
            cookies[name] = value
        conn.close()
    except Exception as e:
        print(f"Cookie error: {e}")
    
    os.unlink(tmp.name)
    return cookies

def download():
    print("Downloading RotoWire injuries...")
    
    # Try direct download first (no auth needed for basic data)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Referer': 'https://www.rotowire.com/cbasketball/injury-report.php'
    }
    
    cookies = get_chrome_cookies()
    print(f"  Found {len(cookies)} RotoWire cookies")
    
    # Try the export endpoint
    url = "https://www.rotowire.com/cbasketball/tables/injury-report.php?team=ALL&pos=ALL"
    r = requests.get(url, headers=headers, cookies=cookies, timeout=30)
    
    print(f"  Response: {r.status_code}, {len(r.text)} bytes")
    
    if r.status_code == 200 and len(r.text) > 100:
        # Check if it's JSON
        try:
            data = r.json()
            if isinstance(data, list) and len(data) > 0:
                print(f"  Got {len(data)} injury records")
                
                # Convert to CSV
                with open(CSV_PATH, 'w') as f:
                    f.write("Player,Team,Pos,Injury,Status,Est. Return\n")
                    for row in data:
                        player = row.get('player', row.get('name', ''))
                        team = row.get('team', '')
                        pos = row.get('pos', row.get('position', ''))
                        injury = row.get('injury', row.get('type', ''))
                        status = row.get('status', 'GTD')
                        est = row.get('return', row.get('est_return', ''))
                        f.write(f'"{player}","{team}","{pos}","{injury}","{status}","{est}"\n')
                
                print(f"  ✓ Saved to {CSV_PATH}")
                return True
        except:
            pass
    
    print("  API failed, trying alternate method...")
    
    # Method 2: Hit the page and look for data in script tags
    url = "https://www.rotowire.com/cbasketball/injury-report.php"
    r = requests.get(url, headers=headers, cookies=cookies, timeout=30)
    
    import re
    import json
    
    # Look for JSON data embedded in the page
    patterns = [
        r'var\s+injuries\s*=\s*(\[.*?\]);',
        r'"injuries"\s*:\s*(\[.*?\])',
        r'data-injuries=\'(\[.*?\])\'',
        r'RW\.data\s*=\s*(\{.*?\});',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, r.text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
                print(f"  Found embedded data: {len(data)} records")
                # Process and save...
                return True
            except:
                continue
    
    print("  ✗ Could not extract data automatically")
    print("\n  MANUAL WORKAROUND:")
    print("  1. Go to: https://www.rotowire.com/cbasketball/injury-report.php")
    print("  2. Scroll to bottom, click 'CSV'")
    print("  3. Run: mv ~/Downloads/college-basketball-injury-report.csv ~/cbb_betting/injuries.csv")
    return False

if __name__ == "__main__":
    download()
