#!/usr/bin/env python3
"""
MATCHUP-SPECIFIC ADJUSTMENTS v3
===============================
Pace mismatch, style clash, and REAL rebounding data.
"""

import os
import sys
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class MatchupAnalyzer:
    """Analyze matchup-specific factors that affect spread."""
    
    AVG_TEMPO = 67.5
    AVG_ORB = 5.5  # League average ORB%
    AVG_DRB = 12.5  # League average DRB%
    
    def __init__(self, team_loader):
        self.loader = team_loader
        self.rebounding = {}
        self._load_rebounding()
    
    def _load_rebounding(self):
        """Load team rebounding data."""
        path = os.path.expanduser("~/cbb_betting/team_rebounding.csv")
        if os.path.exists(path):
            df = pd.read_csv(path)
            for _, r in df.iterrows():
                self.rebounding[r['team'].lower()] = {
                    'orb_pct': float(r['orb_pct']),
                    'drb_pct': float(r['drb_pct'])
                }
            print(f"  ✓ Loaded rebounding for {len(self.rebounding)} teams")
    
    def get_rebounding(self, team):
        """Get team rebounding stats."""
        team_lower = team.lower().strip()
        if team_lower in self.rebounding:
            return self.rebounding[team_lower]
        # Try partial match
        for k, v in self.rebounding.items():
            if team_lower in k or k in team_lower:
                return v
        return {'orb_pct': self.AVG_ORB, 'drb_pct': self.AVG_DRB}
    
    def get_pace_mismatch(self, home, away):
        """Pace mismatch adjustment."""
        home_data = self.loader.get(home)
        away_data = self.loader.get(away)
        
        if not home_data or not away_data:
            return 0.0, ""
        
        home_tempo = home_data.get('adj_t', self.AVG_TEMPO)
        away_tempo = away_data.get('adj_t', self.AVG_TEMPO)
        tempo_diff = abs(home_tempo - away_tempo)
        
        if tempo_diff < 4:
            return 0.0, ""
        
        if home_tempo > away_tempo:
            adj = -min(1.0, (tempo_diff - 4) * 0.12)
            reason = f"Pace mismatch ({tempo_diff:.0f}) favors {away}"
        else:
            adj = min(0.8, (tempo_diff - 4) * 0.10)
            reason = f"Pace mismatch ({tempo_diff:.0f}) → home controls"
        
        return round(adj, 1), reason
    
    def get_style_clash(self, home, away):
        """Elite defense vs elite offense."""
        home_data = self.loader.get(home)
        away_data = self.loader.get(away)
        
        if not home_data or not away_data:
            return 0.0, ""
        
        home_adj_d = home_data.get('adj_d', 100)
        away_adj_d = away_data.get('adj_d', 100)
        home_adj_o = home_data.get('adj_o', 100)
        away_adj_o = away_data.get('adj_o', 100)
        
        adj = 0.0
        reasons = []
        
        if away_adj_d < 95 and home_adj_o > 112:
            adj -= 0.5
            reasons.append(f"Elite away D ({away_adj_d:.0f}) travels")
        
        if home_adj_d < 95 and away_adj_o > 112:
            adj += 0.3
            reasons.append(f"Elite home D ({home_adj_d:.0f}) + crowd")
        
        reason = "; ".join(reasons) if reasons else ""
        return round(adj, 1), reason
    
    def get_rebounding_mismatch(self, home, away):
        """
        REAL rebounding mismatch using ORB% and DRB%.
        
        Formula:
        - Extra possessions = (Team A ORB% - Team B DRB%) difference
        - Each extra possession worth ~1 point
        - Capped at ±1.5 pts
        
        Example:
        - Home ORB% = 8.0, Away DRB% = 11.0 → Home gets extra offensive boards
        - Away ORB% = 4.0, Home DRB% = 14.0 → Home limits 2nd chances
        """
        home_reb = self.get_rebounding(home)
        away_reb = self.get_rebounding(away)
        
        home_data = self.loader.get(home)
        away_data = self.loader.get(away)
        
        if not home_data or not away_data:
            return 0.0, ""
        
        # Home offensive rebounding advantage
        # Home ORB% vs Away DRB% (higher ORB vs lower DRB = more 2nd chances)
        home_orb_edge = home_reb['orb_pct'] - self.AVG_ORB  # vs league avg
        away_drb_edge = away_reb['drb_pct'] - self.AVG_DRB  # vs league avg
        
        # Away offensive rebounding advantage
        away_orb_edge = away_reb['orb_pct'] - self.AVG_ORB
        home_drb_edge = home_reb['drb_pct'] - self.AVG_DRB
        
        # Net rebounding advantage for home team
        # Positive = home advantage, negative = away advantage
        home_2nd_chance = home_orb_edge - away_drb_edge  # Home getting 2nd chances
        away_2nd_chance = away_orb_edge - home_drb_edge  # Away getting 2nd chances
        
        net_reb_edge = home_2nd_chance - away_2nd_chance
        
        # Convert to points: each 1% ORB edge ≈ 0.3 points
        adj = net_reb_edge * 0.25
        adj = max(-1.5, min(1.5, adj))  # Cap
        
        if abs(adj) < 0.3:
            return 0.0, ""
        
        reason = ""
        if adj > 0.3:
            reason = f"Home reb edge (ORB {home_reb['orb_pct']:.1f}% vs {away_reb['orb_pct']:.1f}%)"
        elif adj < -0.3:
            reason = f"Away reb edge (ORB {away_reb['orb_pct']:.1f}% vs {home_reb['orb_pct']:.1f}%)"
        
        return round(adj, 1), reason
    
    def get_all_adjustments(self, home, away):
        """Get all matchup adjustments combined."""
        total_adj = 0.0
        all_factors = []
        
        adj, reason = self.get_pace_mismatch(home, away)
        if adj != 0:
            total_adj += adj
            all_factors.append(reason)
        
        adj, reason = self.get_style_clash(home, away)
        if adj != 0:
            total_adj += adj
            all_factors.append(reason)
        
        adj, reason = self.get_rebounding_mismatch(home, away)
        if adj != 0:
            total_adj += adj
            all_factors.append(reason)
        
        return round(total_adj, 1), all_factors


if __name__ == "__main__":
    import pandas as pd
    
    class SimpleLoader:
        def __init__(self):
            path = os.path.expanduser("~/cbb_betting/barttorvik_2026.csv")
            df = pd.read_csv(path)
            self.teams = {}
            for _, r in df.iterrows():
                n = r['team']
                self.teams[n.lower()] = {
                    'team': n, 'rank': int(r['rank']), 'conf': r['conf'],
                    'adj_o': float(r['adjoe']), 'adj_d': float(r['adjde']),
                    'adj_t': float(r['adjt'])
                }
        def get(self, name):
            return self.teams.get(name.lower().strip())
    
    loader = SimpleLoader()
    analyzer = MatchupAnalyzer(loader)
    
    print("\n" + "="*70)
    print("MATCHUP ADJUSTMENTS v3 - WITH REAL REBOUNDING")
    print("="*70)
    
    matchups = [
        ('Loyola Chicago', 'Dayton'),
        ('Alabama', 'Kentucky'),
        ('Arkansas', 'Tennessee'),
        ('Kansas St.', 'BYU'),
        ('High Point', 'Longwood'),
        ('Eastern Michigan', 'Ohio'),
    ]
    
    for home, away in matchups:
        home_reb = analyzer.get_rebounding(home)
        away_reb = analyzer.get_rebounding(away)
        adj, factors = analyzer.get_all_adjustments(home, away)
        
        print(f"\n{away} @ {home}")
        print(f"  Home reb: ORB {home_reb['orb_pct']:.1f}%, DRB {home_reb['drb_pct']:.1f}%")
        print(f"  Away reb: ORB {away_reb['orb_pct']:.1f}%, DRB {away_reb['drb_pct']:.1f}%")
        print(f"  Total adj: {adj:+.1f}")
        if factors:
            for f in factors:
                print(f"    • {f}")
        else:
            print(f"    • (no adjustment)")
