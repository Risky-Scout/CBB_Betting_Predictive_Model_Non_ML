#!/usr/bin/env python3
"""Quick script to enter bet results."""

import pandas as pd
import os

LOG_PATH = os.path.expanduser("~/cbb_betting/bet_log.csv")

def main():
    df = pd.read_csv(LOG_PATH)
    
    # Find pending bets
    pending = df[df['result'].isna() | (df['result'] == '')]
    
    if len(pending) == 0:
        print("No pending bets!")
        show_summary(df)
        return
    
    print("="*60)
    print("PENDING BETS")
    print("="*60)
    
    for idx, row in pending.iterrows():
        print(f"\n{row['date']} | {row['game']}")
        print(f"  Bet: {row['bet']} {row['line']} (${row['stake']})")
        result = input("  Result (W/L/P or skip): ").strip().upper()
        
        if result in ['W', 'L', 'P']:
            df.at[idx, 'result'] = result
            if result == 'W':
                df.at[idx, 'profit'] = round(float(row['stake']) * 0.909, 2)
            elif result == 'L':
                df.at[idx, 'profit'] = -float(row['stake'])
            else:
                df.at[idx, 'profit'] = 0
    
    df.to_csv(LOG_PATH, index=False)
    print("\n✓ Results saved!")
    
    show_summary(df)

def show_summary(df):
    print("\n" + "="*60)
    print("BETTING SUMMARY")
    print("="*60)
    
    completed = df[df['result'].isin(['W', 'L', 'P'])]
    
    if len(completed) == 0:
        print("\nNo completed bets yet.")
        return
    
    wins = len(completed[completed['result'] == 'W'])
    losses = len(completed[completed['result'] == 'L'])
    pushes = len(completed[completed['result'] == 'P'])
    total = wins + losses
    
    profit = completed['profit'].astype(float).sum()
    total_staked = completed['stake'].astype(float).sum()
    
    print(f"\nRecord: {wins}-{losses}-{pushes}")
    if total > 0:
        print(f"Win %: {wins/total*100:.1f}%")
    print(f"Total Staked: ${total_staked:,.0f}")
    print(f"Profit: ${profit:+,.2f}")
    if total_staked > 0:
        print(f"ROI: {profit/total_staked*100:+.1f}%")
    
    # By date
    print("\n" + "-"*40)
    print("BY DATE:")
    for date in completed['date'].unique():
        day = completed[completed['date'] == date]
        day_profit = day['profit'].astype(float).sum()
        day_record = f"{len(day[day['result']=='W'])}-{len(day[day['result']=='L'])}"
        print(f"  {date}: {day_record} | ${day_profit:+,.0f}")

if __name__ == "__main__":
    main()
