#!/usr/bin/env python3
"""
NEUTRAL SITE DETECTION
======================
Tournaments and special events have no home court advantage.
"""

# Known neutral site tournaments/events
NEUTRAL_KEYWORDS = [
    'tournament', 'classic', 'invitational', 'challenge',
    'showdown', 'showcase', 'battle', 'tipoff', 'shootout'
]

# Conference tournament venues (typically neutral)
CONF_TOURNEY_VENUES = [
    'las vegas', 'kansas city', 'nashville', 'atlanta',
    'new york', 'madison square', 'brooklyn', 'greensboro',
    'st. louis', 'indianapolis', 'phoenix', 'dallas'
]

# NCAA Tournament sites
NCAA_SITES = [
    'march madness', 'ncaa tournament', 'sweet 16', 
    'elite 8', 'final four'
]

def is_neutral_site(game_info):
    """
    Determine if a game is at a neutral site.
    
    Returns:
        True if neutral site (HCA = 0)
        False if home game (normal HCA)
    """
    # Check game title/description if available
    title = game_info.get('title', '').lower()
    venue = game_info.get('venue', '').lower()
    
    # Check for tournament keywords
    for kw in NEUTRAL_KEYWORDS:
        if kw in title or kw in venue:
            return True
    
    # Check for known neutral venues
    for v in CONF_TOURNEY_VENUES:
        if v in venue:
            return True
    
    # Check for NCAA tournament
    for n in NCAA_SITES:
        if n in title:
            return True
    
    # Default: assume home game
    return False

def get_hca_adjustment(game_info, base_hca=3.5):
    """
    Get home court advantage for a game.
    
    Returns:
        0 if neutral site
        base_hca if home game
    """
    if is_neutral_site(game_info):
        return 0.0
    return base_hca


# Date-based detection for conference tournaments
CONF_TOURNEY_DATES = {
    # 2026 conference tournament dates (approximate)
    'march': list(range(3, 16)),  # March 3-15 typically
}

def is_conference_tournament_date(date):
    """Check if date falls during conference tournament season."""
    if date.month == 3 and date.day in CONF_TOURNEY_DATES['march']:
        return True
    return False


if __name__ == "__main__":
    # Test cases
    tests = [
        {'title': 'Regular Season', 'venue': 'Cameron Indoor'},
        {'title': 'Maui Invitational', 'venue': 'Lahaina Civic Center'},
        {'title': 'ACC Tournament', 'venue': 'Greensboro Coliseum'},
        {'title': 'NCAA Tournament Round 1', 'venue': 'Pittsburgh'},
        {'title': 'Big 12 Championship', 'venue': 'Kansas City'},
    ]
    
    print("NEUTRAL SITE DETECTION TEST")
    print("="*50)
    for t in tests:
        neutral = is_neutral_site(t)
        hca = get_hca_adjustment(t)
        print(f"\n{t['title']} @ {t['venue']}")
        print(f"  Neutral: {neutral}")
        print(f"  HCA: {hca}")
