# CBB Betting Syndicate v7.4 (ML Enhanced)

## Features

### Core Model
- **T-Rank Efficiency Model**: Barttorvik-based predictions
- **Player-Level Injuries**: 3,750+ players with BPM impact
- **Minutes Redistribution**: Replacement player logic
- **Real Rebounding**: ORB% and DRB% by team

### Adjustments
- **Matchup Analysis**: Pace, style, rebounding mismatches
- **Travel/Timezone**: Cross-country fatigue factors
- **Rest Tracking**: B2B and rest edge detection
- **Line Movement**: Sharp money indicators

### ML Layer
- **Gradient Boosting Model**: Trained on 5,025 games
- **Confidence Scoring**: Adjusts bet sizing 0.7x to 1.3x
- **Historical Validation**: 57-92% cover rates by edge tier

### Contrarian Edge
- **Public Betting %**: Fade heavy public action
- **Kelly Adjustment**: +15% for strong contrarian, -10% for public heavy

### Tracking
- **CLV Tracker**: Closing line value for model validation
- **Auto-Logging**: All bets saved to bet_log.csv

### Tournament Mode (March)
- **Neutral Site Detection**: Conference and NCAA tournaments
- **Fatigue Factors**: B2B and 3-in-4 days
- **Bye Advantages**: Higher seed rest edge

## Quick Start
```bash

# Backup tournament mode
cp ~/cbb_betting/tournament_mode.py ~/cbb_betting/backups/

# Create final ML package for GitHub
mkdir -p ~/cbb_betting/CBB_MODEL_ML

# Copy all files
cp ~/cbb_betting/enhanced_betting_system_v7.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/matchup_adjustments.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/travel_adjustment.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/team_mapping.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/injury_loader.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/player_projections.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/minutes_redistribution.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/data_fetchers.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/line_movement.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/download_injuries.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/enter_results.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/neutral_site.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/ml_confidence.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/ml_confidence_model.pkl ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/ml_features.txt ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/public_betting.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/clv_tracker.py ~/cbb_betting/CBB_MODEL_ML/
cp ~/cbb_betting/tournament_mode.py ~/cbb_betting/CBB_MODEL_ML/

# Create run script
cat > ~/cbb_betting/CBB_MODEL_ML/run_model.sh << 'RUNEOF'
#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "========================================"
echo "CBB BETTING SYNDICATE v7.4"
echo "ML + CONTRARIAN + CLV"
echo "$(date)"
echo "========================================"

API_KEY="${1:-da45cdad6addfa18598c567d02ccd848}"

echo ""
echo "[1/4] Updating data..."
curl -s -o barttorvik_2026.csv "https://barttorvik.com/2026_team_results.csv"
python3 download_injuries.py 2>/dev/null

echo ""
echo "[2/4] Updating rebounding..."
python3 << 'PYEOF'
import requests, pandas as pd, os
url = "https://barttorvik.com/getadvstats.php?year=2026&csv=1"
r = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=30)
lines = r.text.strip().split('\n')
team_reb = {}
for line in lines[1:]:
    parts, current, in_q = [], "", False
    for c in line:
        if c == '"': in_q = not in_q
        elif c == ',' and not in_q: parts.append(current.strip().strip('"')); current = ""
        else: current += c
    parts.append(current.strip().strip('"'))
    if len(parts) < 15: continue
    try:
        team, mpg = parts[1], float(parts[4]) if parts[4] else 0
        orb, drb = float(parts[9]) if parts[9] else 0, float(parts[10]) if parts[10] else 0
        if mpg < 10: continue
        if team not in team_reb: team_reb[team] = {'orb_sum': 0, 'drb_sum': 0, 'mpg_sum': 0}
        team_reb[team]['orb_sum'] += orb * mpg
        team_reb[team]['drb_sum'] += drb * mpg
        team_reb[team]['mpg_sum'] += mpg
    except: continue
stats = [{'team': t, 'orb_pct': round(s['orb_sum']/s['mpg_sum'], 1), 'drb_pct': round(s['drb_sum']/s['mpg_sum'], 1)} for t, s in team_reb.items() if s['mpg_sum'] > 0]
pd.DataFrame(stats).to_csv("team_rebounding.csv", index=False)
print(f"  ✓ {len(stats)} teams")
PYEOF

echo ""
echo "[3/4] Running model..."
python3 enhanced_betting_system_v7.py --odds-key "$API_KEY"

echo ""
echo "[4/4] Done!"
echo ""
echo "Commands:"
echo "  Results:  python3 enter_results.py"
echo "  CLV:      python3 clv_tracker.py report"
echo "  Public:   python3 public_betting.py entry"
RUNEOF

chmod +x ~/cbb_betting/CBB_MODEL_ML/run_model.sh

# Create README
cat > ~/cbb_betting/CBB_MODEL_ML/README.md << 'READMEEOF'
# CBB Betting Syndicate v7.4 (ML Enhanced)

## Features

### Core Model
- **T-Rank Efficiency Model**: Barttorvik-based predictions
- **Player-Level Injuries**: 3,750+ players with BPM impact
- **Minutes Redistribution**: Replacement player logic
- **Real Rebounding**: ORB% and DRB% by team

### Adjustments
- **Matchup Analysis**: Pace, style, rebounding mismatches
- **Travel/Timezone**: Cross-country fatigue factors
- **Rest Tracking**: B2B and rest edge detection
- **Line Movement**: Sharp money indicators

### ML Layer
- **Gradient Boosting Model**: Trained on 5,025 games
- **Confidence Scoring**: Adjusts bet sizing 0.7x to 1.3x
- **Historical Validation**: 57-92% cover rates by edge tier

### Contrarian Edge
- **Public Betting %**: Fade heavy public action
- **Kelly Adjustment**: +15% for strong contrarian, -10% for public heavy

### Tracking
- **CLV Tracker**: Closing line value for model validation
- **Auto-Logging**: All bets saved to bet_log.csv

### Tournament Mode (March)
- **Neutral Site Detection**: Conference and NCAA tournaments
- **Fatigue Factors**: B2B and 3-in-4 days
- **Bye Advantages**: Higher seed rest edge

## Quick Start
```bash
./run_model.sh
```

Or with custom API key:
```bash
./run_model.sh YOUR_API_KEY
```

## Daily Workflow

**Morning:**
```bash
./run_model.sh
```

**Evening:**
```bash
python3 enter_results.py
```

**Check CLV:**
```bash
python3 clv_tracker.py report
```

**Add Public %:**
```bash
python3 public_betting.py entry
```

## Historical Performance (2025 Season)

| Edge | Cover Rate | Games |
|------|------------|-------|
| 0-2 pts | 57.2% | 916 |
| 2-4 pts | 60.8% | 957 |
| 4-6 pts | 67.3% | 817 |
| 6-8 pts | 69.7% | 684 |
| 8-10 pts | 74.5% | 541 |
| 10-15 pts | 83.0% | 788 |
| 15+ pts | 92.1% | 318 |

## Requirements
```bash
pip install pandas numpy scipy requests beautifulsoup4 scikit-learn
```

## Files

| File | Purpose |
|------|---------|
| `enhanced_betting_system_v7.py` | Main model |
| `ml_confidence.py` | ML confidence layer |
| `ml_confidence_model.pkl` | Trained ML model |
| `public_betting.py` | Contrarian betting |
| `clv_tracker.py` | CLV tracking |
| `tournament_mode.py` | March tournament adjustments |
| `run_model.sh` | One-click daily script |

## API Key

Get free key at: https://the-odds-api.com/

## License

For personal use only. Not financial advice.
