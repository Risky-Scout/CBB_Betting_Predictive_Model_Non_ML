#!/usr/bin/env python3
"""INJURY LOADER - Reads RotoWire CSV Export"""

import os
import csv
from datetime import datetime
from typing import Dict, List, Tuple

class InjuryLoader:
    CSV_PATH = os.path.expanduser("~/cbb_betting/injuries.csv")
    
    def __init__(self):
        self.injuries = {}
        self.last_update = ""
    
    def load(self):
        if not os.path.exists(self.CSV_PATH):
            print(f"  No injury file at {self.CSV_PATH}")
            return False
        
        mtime = datetime.fromtimestamp(os.path.getmtime(self.CSV_PATH))
        self.injuries = {}
        total = 0
        
        # Use utf-8-sig to handle BOM character
        with open(self.CSV_PATH, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                player = row.get('Player', '').strip()
                team = row.get('Team', '').strip()
                position = row.get('Pos', '').strip()
                injury = row.get('Injury', '').strip()
                status_raw = row.get('Status', '').upper()
                
                if not player or not team:
                    continue
                
                # Parse status
                if 'OUT' in status_raw:
                    status = 'OUT'
                elif 'DOUBT' in status_raw:
                    status = 'DOUBTFUL'
                elif 'GAME TIME' in status_raw or 'GTD' in status_raw:
                    status = 'GTD'
                elif 'QUEST' in status_raw:
                    status = 'QUESTIONABLE'
                elif 'DAY' in status_raw:
                    status = 'DAY-TO-DAY'
                else:
                    status = 'UNKNOWN'
                
                team_key = team.lower()
                if team_key not in self.injuries:
                    self.injuries[team_key] = []
                
                self.injuries[team_key].append({
                    'player': player,
                    'position': position,
                    'injury': injury,
                    'status': status
                })
                total += 1
        
        self.last_update = mtime.strftime('%Y-%m-%d %H:%M')
        print(f"  ✓ Loaded {total} injuries for {len(self.injuries)} teams")
        return True
    
    def get_team_injuries(self, team):
        key = team.lower()
        if key in self.injuries:
            return self.injuries[key]
        for k, v in self.injuries.items():
            if key in k or k in key:
                return v
        return []
    
    def get_injury_impact(self, team):
        injuries = self.get_team_injuries(team)
        if not injuries:
            return 0.0, []
        
        total = 0.0
        players = []
        for inj in injuries:
            status = inj['status']
            player = inj['player']
            pos = inj['position']
            injury_type = inj['injury']
            
            if status == 'OUT':
                total += 2.5
                players.append(f"{player} ({pos}) OUT - {injury_type}")
            elif status == 'DOUBTFUL':
                total += 2.0
                players.append(f"{player} ({pos}) DOUBT - {injury_type}")
            elif status == 'GTD':
                total += 1.0
                players.append(f"{player} ({pos}) GTD - {injury_type}")
            elif status == 'DAY-TO-DAY':
                total += 0.8
                players.append(f"{player} ({pos}) DTD - {injury_type}")
        
        return total, players[:5]
    
    def print_all(self):
        print(f"\n  ALL INJURIES ({self.last_update}):")
        for team in sorted(self.injuries.keys()):
            print(f"\n  {team.upper()}:")
            for inj in self.injuries[team]:
                print(f"    {inj['player']} ({inj['position']}): {inj['status']} - {inj['injury']}")

if __name__ == "__main__":
    print("="*70)
    print("INJURY LOADER TEST")
    print("="*70)
    loader = InjuryLoader()
    if loader.load():
        loader.print_all()
        print("\n" + "="*70)
        print("IMPACT BY TEAM")
        print("="*70)
        for team in ['Louisville', 'Delaware', 'Oregon', 'West Virginia', 'Nebraska', 'Maryland']:
            impact, players = loader.get_injury_impact(team)
            if impact > 0:
                print(f"\n  {team}: {impact:+.1f} pts")
                for p in players:
                    print(f"    └─ {p}")
