#!/usr/bin/env python3
"""
CLOSING LINE VALUE (CLV) TRACKER
================================
CLV = The difference between your bet line and the closing line.
Positive CLV = Line moved in your favor = Long-term edge.

Example:
- You bet Team A -3.5
- Line closes at Team A -5.0
- CLV = +1.5 (you got 1.5 points better than market)

This is the #1 indicator of betting skill.
Professional bettors aim for +0.5 to +2.0 CLV per bet.
"""

import os
import json
from datetime import datetime
import requests

class CLVTracker:
    """Track closing line value for all bets."""
    
    def __init__(self, odds_api_key=None):
        self.api_key = odds_api_key
        self.data_path = os.path.expanduser("~/cbb_betting/clv_data.json")
        self.data = self._load_data()
    
    def _load_data(self):
        if os.path.exists(self.data_path):
            with open(self.data_path, 'r') as f:
                return json.load(f)
        return {'bets': [], 'closing_lines': {}}
    
    def _save_data(self):
        with open(self.data_path, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def record_bet(self, game_key, bet_team, bet_line, edge=None, bet_time=None):
        """Record a bet with its line."""
        if bet_time is None:
            bet_time = datetime.now().isoformat()
        
        # Check if already recorded
        for b in self.data['bets']:
            if b['game_key'] == game_key and b['bet_team'] == bet_team:
                return  # Already tracked
        
        self.data['bets'].append({
            'game_key': game_key,
            'bet_team': bet_team,
            'bet_line': bet_line,
            'edge': edge,
            'bet_time': bet_time,
            'closing_line': None,
            'clv': None
        })
        self._save_data()
    
    def record_closing_line(self, game_key, home_spread):
        """Record the closing line for a game."""
        self.data['closing_lines'][game_key] = {
            'home_spread': home_spread,
            'recorded_at': datetime.now().isoformat()
        }
        
        # Update CLV for any bets on this game
        self._calculate_clv(game_key, home_spread)
        self._save_data()
    
    def _calculate_clv(self, game_key, closing_home_spread):
        """Calculate CLV for bets on this game."""
        parts = game_key.split(' @ ')
        if len(parts) != 2:
            return
        away_team, home_team = parts
        
        for bet in self.data['bets']:
            if bet['game_key'] == game_key and bet['clv'] is None:
                # Get closing line for the side you bet
                if home_team.lower() in bet['bet_team'].lower():
                    # Bet on home: your line is the home spread you got
                    # Closing line is what home closed at
                    # CLV = closing - your_line (negative spread, more negative = stronger favorite)
                    # If you got -3.5 and it closed -5.0, you got 1.5 pts better
                    bet['closing_line'] = closing_home_spread
                    bet['clv'] = round(bet['bet_line'] - closing_home_spread, 1)
                else:
                    # Bet on away: your line is positive (or less negative)
                    # Away spread = -home_spread
                    closing_away = -closing_home_spread
                    bet['closing_line'] = closing_away
                    # If you got +3.5 and it closed +5.0, line moved against you
                    # CLV = closing - your_line = 5.0 - 3.5 = +1.5 (good, you got fewer points but line moved your way)
                    # Actually for dogs: if you got +3.5 and closed +2.5, you got more points = good
                    bet['clv'] = round(bet['bet_line'] - closing_away, 1)
    
    def get_clv_summary(self):
        """Get summary statistics of CLV performance."""
        bets_with_clv = [b for b in self.data['bets'] if b['clv'] is not None]
        
        if not bets_with_clv:
            return None
        
        clvs = [b['clv'] for b in bets_with_clv]
        
        return {
            'total_bets': len(bets_with_clv),
            'avg_clv': round(sum(clvs) / len(clvs), 2),
            'positive_clv_pct': round(len([c for c in clvs if c > 0]) / len(clvs) * 100, 1),
            'total_clv': round(sum(clvs), 1),
            'best_clv': max(clvs),
            'worst_clv': min(clvs),
        }
    
    def get_pending_bets(self):
        """Get bets without closing lines."""
        return [b for b in self.data['bets'] if b['clv'] is None]
    
    def print_report(self):
        """Print CLV performance report."""
        summary = self.get_clv_summary()
        
        print("="*60)
        print("CLOSING LINE VALUE (CLV) REPORT")
        print("="*60)
        
        if not summary:
            pending = self.get_pending_bets()
            if pending:
                print(f"\n{len(pending)} bets awaiting closing lines:")
                for b in pending[-5:]:
                    print(f"  • {b['bet_team']} {b['bet_line']:+.1f} ({b['game_key'][:30]})")
                print("\nRun at game time: python3 clv_tracker.py fetch API_KEY")
            else:
                print("\nNo bets tracked yet.")
            return
        
        print(f"\nTotal Bets Tracked: {summary['total_bets']}")
        print(f"\nCLV Performance:")
        print(f"  Average CLV:     {summary['avg_clv']:+.2f} pts")
        print(f"  Positive CLV %:  {summary['positive_clv_pct']:.1f}%")
        print(f"  Total CLV:       {summary['total_clv']:+.1f} pts")
        print(f"  Best CLV:        {summary['best_clv']:+.1f} pts")
        print(f"  Worst CLV:       {summary['worst_clv']:+.1f} pts")
        
        print("\n" + "-"*60)
        print("INTERPRETATION:")
        print("-"*60)
        
        avg = summary['avg_clv']
        if avg >= 1.0:
            print("  ★★★ EXCELLENT - Consistently beating the market")
            print("      Sharp-level performance")
        elif avg >= 0.3:
            print("  ★★☆ GOOD - Positive expected value")
            print("      Model finding real edges before market")
        elif avg >= -0.3:
            print("  ★☆☆ NEUTRAL - Breaking even vs market")
            print("      Competitive but room for improvement")
        else:
            print("  ☆☆☆ NEGATIVE - Getting bad numbers")
            print("      Bet earlier or shop lines better")
        
        # Recent bets
        print("\n" + "-"*60)
        print("RECENT BETS:")
        print("-"*60)
        recent = self.data['bets'][-10:]
        for bet in recent:
            if bet['clv'] is not None:
                clv_str = f"CLV: {bet['clv']:+.1f}"
                close_str = f"Close: {bet['closing_line']:+.1f}"
            else:
                clv_str = "Pending"
                close_str = "..."
            print(f"  {bet['bet_team'][:15]:<15} {bet['bet_line']:+.1f} → {close_str:<12} {clv_str}")


def fetch_closing_lines(api_key):
    """Fetch current lines (use at game time for closing lines)."""
    try:
        r = requests.get(
            "https://api.the-odds-api.com/v4/sports/basketball_ncaab/odds",
            params={'apiKey': api_key, 'regions': 'us', 'markets': 'spreads'},
            timeout=30
        )
        if r.status_code != 200:
            return {}
        
        lines = {}
        for g in r.json():
            home = g.get('home_team', '')
            away = g.get('away_team', '')
            game_key = f"{away} @ {home}"
            
            spreads = []
            for b in g.get('bookmakers', []):
                for m in b.get('markets', []):
                    if m['key'] == 'spreads':
                        for o in m['outcomes']:
                            if o['name'] == home:
                                spreads.append(o.get('point', 0))
            
            if spreads:
                lines[game_key] = round(sum(spreads) / len(spreads), 1)
        
        return lines
    except Exception as e:
        print(f"Error fetching lines: {e}")
        return {}


if __name__ == "__main__":
    import sys
    
    tracker = CLVTracker()
    
    if len(sys.argv) > 1:
        if sys.argv[1] == 'report':
            tracker.print_report()
        elif sys.argv[1] == 'fetch' and len(sys.argv) > 2:
            api_key = sys.argv[2]
            print("Fetching current lines as closing lines...")
            lines = fetch_closing_lines(api_key)
            print(f"Got {len(lines)} lines")
            
            # Record closing lines for pending bets
            pending = tracker.get_pending_bets()
            matched = 0
            for bet in pending:
                if bet['game_key'] in lines:
                    tracker.record_closing_line(bet['game_key'], lines[bet['game_key']])
                    matched += 1
            
            print(f"✓ Matched {matched}/{len(pending)} pending bets")
            tracker.print_report()
        elif sys.argv[1] == 'clear':
            os.remove(tracker.data_path)
            print("✓ CLV data cleared")
    else:
        tracker.print_report()
        print("\nCommands:")
        print("  python3 clv_tracker.py report           # Show report")
        print("  python3 clv_tracker.py fetch API_KEY    # Record closing lines")
        print("  python3 clv_tracker.py clear            # Clear all data")
