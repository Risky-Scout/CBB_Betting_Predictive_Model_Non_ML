#!/usr/bin/env python3
"""
CONFERENCE TOURNAMENT MODE
==========================
Special adjustments for March tournament betting:

1. Neutral site detection (HCA = 0)
2. Tournament fatigue (B2B/3-in-4 days)
3. Motivation factors (bubble teams, revenge games)
4. Bracket position (bye advantages)
5. Travel considerations

Conference tournaments: March 3-15
NCAA Tournament: March 18 - April 7
"""

import os
from datetime import datetime, date

# Conference tournament dates (2026 estimates)
CONF_TOURNEY_START = date(2026, 3, 3)
CONF_TOURNEY_END = date(2026, 3, 15)
NCAA_START = date(2026, 3, 18)
NCAA_END = date(2026, 4, 7)

# Conference tournament venues
CONF_TOURNEY_VENUES = {
    'ACC': 'Washington, DC',
    'B10': 'Indianapolis',
    'B12': 'Kansas City',
    'SEC': 'Nashville',
    'BE': 'New York',
    'PAC': 'Las Vegas',
    'MWC': 'Las Vegas',
    'WCC': 'Las Vegas',
    'A10': 'Brooklyn',
    'AAC': 'Fort Worth',
    'MVC': 'St. Louis',
    'CUSA': 'Las Vegas',
    'MAC': 'Cleveland',
    'SBC': 'Lafayette',
}

# Teams likely on NCAA bubble (update weekly in March)
BUBBLE_TEAMS_2026 = [
    # Will be populated as season progresses
]

class TournamentMode:
    """Adjustments for tournament betting."""
    
    def __init__(self):
        self.active = self._check_tournament_season()
    
    def _check_tournament_season(self):
        """Check if we're in tournament season."""
        today = date.today()
        return CONF_TOURNEY_START <= today <= NCAA_END
    
    def is_neutral_site(self, game_info):
        """
        Determine if game is at neutral site.
        
        Args:
            game_info: dict with 'title', 'venue', 'home_conf', 'away_conf'
        
        Returns:
            True if neutral site
        """
        title = game_info.get('title', '').lower()
        venue = game_info.get('venue', '').lower()
        
        # Tournament keywords
        tournament_keywords = [
            'tournament', 'championship', 'classic', 'invitational',
            'challenge', 'shootout', 'battle', 'showcase',
            'ncaa', 'march madness', 'sweet 16', 'elite 8', 'final four'
        ]
        
        for kw in tournament_keywords:
            if kw in title or kw in venue:
                return True
        
        # Known neutral venues
        neutral_venues = [
            'las vegas', 'kansas city', 'nashville', 'indianapolis',
            'new york', 'msg', 'madison square', 'brooklyn', 'barclays',
            'greensboro', 'charlotte', 'atlanta', 'st. louis', 'denver'
        ]
        
        for nv in neutral_venues:
            if nv in venue:
                return True
        
        # Date-based: conference tournament week
        today = date.today()
        if CONF_TOURNEY_START <= today <= CONF_TOURNEY_END:
            # During conf tourneys, check if it's a tournament game
            if 'semifinal' in title or 'final' in title or 'quarterfinal' in title:
                return True
        
        return False
    
    def get_tournament_adjustments(self, home_team, away_team, game_info=None):
        """
        Get all tournament-specific adjustments.
        
        Returns:
            (total_adjustment, list of factors)
        """
        if not self.active:
            return 0.0, []
        
        adj = 0.0
        factors = []
        game_info = game_info or {}
        
        # 1. Neutral site = no HCA
        if self.is_neutral_site(game_info):
            # Return negative adjustment to cancel out the HCA added elsewhere
            adj -= 3.5  # Cancel default HCA
            factors.append("Neutral site (no HCA)")
        
        # 2. Tournament fatigue
        home_games_in_3_days = game_info.get('home_recent_games', 0)
        away_games_in_3_days = game_info.get('away_recent_games', 0)
        
        if away_games_in_3_days >= 2:
            adj += 0.8  # Favors home (away team tired)
            factors.append(f"Away fatigue ({away_games_in_3_days} games in 3 days)")
        if home_games_in_3_days >= 2:
            adj -= 0.8  # Favors away (home team tired)
            factors.append(f"Home fatigue ({home_games_in_3_days} games in 3 days)")
        
        # 3. Bye advantage (higher seed didn't play yesterday)
        home_seed = game_info.get('home_seed', 0)
        away_seed = game_info.get('away_seed', 0)
        
        if home_seed and away_seed:
            if home_seed <= 4 and away_seed > 4:
                adj += 0.5
                factors.append(f"Home bye advantage (#{home_seed} seed)")
            elif away_seed <= 4 and home_seed > 4:
                adj -= 0.5
                factors.append(f"Away bye advantage (#{away_seed} seed)")
        
        # 4. Bubble team motivation
        if home_team in BUBBLE_TEAMS_2026:
            adj += 0.3
            factors.append("Home bubble team (motivated)")
        if away_team in BUBBLE_TEAMS_2026:
            adj -= 0.3
            factors.append("Away bubble team (motivated)")
        
        return round(adj, 1), factors
    
    def get_hca_for_game(self, game_info, default_hca=3.5):
        """Get appropriate HCA for a game."""
        if self.is_neutral_site(game_info):
            return 0.0
        return default_hca
    
    def print_status(self):
        """Print tournament mode status."""
        today = date.today()
        
        print("="*50)
        print("TOURNAMENT MODE STATUS")
        print("="*50)
        
        if today < CONF_TOURNEY_START:
            days_until = (CONF_TOURNEY_START - today).days
            print(f"\nRegular season - {days_until} days until conference tournaments")
            print(f"Conference tournaments: {CONF_TOURNEY_START} - {CONF_TOURNEY_END}")
            print(f"NCAA Tournament: {NCAA_START} - {NCAA_END}")
        elif today <= CONF_TOURNEY_END:
            print(f"\n🏀 CONFERENCE TOURNAMENT WEEK!")
            print(f"  • Neutral sites active")
            print(f"  • Fatigue factors enabled")
            print(f"  • Bye advantages tracked")
        elif today <= NCAA_END:
            print(f"\n🏆 NCAA TOURNAMENT!")
            print(f"  • All games neutral site")
            print(f"  • Maximum fatigue adjustments")
            print(f"  • Single elimination pressure")
        else:
            print(f"\nOffseason - Tournament mode inactive")
        
        print(f"\nMode active: {self.active}")


if __name__ == "__main__":
    tm = TournamentMode()
    tm.print_status()
    
    print("\n" + "="*50)
    print("NEUTRAL SITE DETECTION TEST")
    print("="*50)
    
    tests = [
        {'title': 'Regular Season', 'venue': 'Cameron Indoor Stadium'},
        {'title': 'ACC Tournament Semifinal', 'venue': 'Capital One Arena'},
        {'title': 'Big 12 Championship', 'venue': 'T-Mobile Center, Kansas City'},
        {'title': 'NCAA Tournament Round 1', 'venue': 'PPG Paints Arena'},
        {'title': 'Maui Invitational', 'venue': 'Lahaina Civic Center'},
        {'title': 'Regular game', 'venue': 'Madison Square Garden'},
    ]
    
    for t in tests:
        neutral = tm.is_neutral_site(t)
        hca = tm.get_hca_for_game(t)
        print(f"\n  {t['title'][:30]:<30} @ {t['venue'][:25]:<25}")
        print(f"    Neutral: {neutral} | HCA: {hca}")
