#!/usr/bin/env python3
"""
HEAD-TO-HEAD & RIVALRY ADJUSTMENTS
==================================
Adjusts predictions for:
1. Rivalry games (extra motivation, closer than expected)
2. Historical dominance (one team owns the series)
"""

# Known intense rivalries - games tend to be closer than efficiency suggests
RIVALRIES = {
    # ACC
    ('Duke', 'North Carolina'), ('Louisville', 'Kentucky'),
    # Big Ten
    ('Michigan', 'Ohio St.'), ('Indiana', 'Purdue'), ('Michigan', 'Michigan St.'),
    # Big 12
    ('Kansas', 'Kansas St.'), ('Iowa St.', 'Iowa'),
    # SEC
    ('Kentucky', 'Tennessee'), ('Auburn', 'Alabama'),
    # Pac-12 / West
    ('Arizona', 'Arizona St.'), ('UCLA', 'USC'), ('Oregon', 'Oregon St.'),
    # Big East
    ('Georgetown', 'Syracuse'), ('UConn', 'Syracuse'),
    # WCC
    ('Gonzaga', 'Saint Mary\'s'), ('BYU', 'Utah'),
    # Other
    ('Cincinnati', 'Xavier'),
}

def is_rivalry(team1, team2):
    """Check if two teams are rivals."""
    t1, t2 = team1.lower().strip(), team2.lower().strip()
    for r1, r2 in RIVALRIES:
        if (r1.lower() == t1 and r2.lower() == t2) or (r1.lower() == t2 and r2.lower() == t1):
            return True
    return False

def get_rivalry_adjustment(home_team, away_team, predicted_margin):
    """
    Get adjustment for rivalry games.
    
    Rivalry games tend to be closer than predicted.
    Regress big spreads toward the mean.
    
    Returns:
        (adjustment, reason) - adjustment to home margin
    """
    if not is_rivalry(home_team, away_team):
        return 0.0, None
    
    # Rivalry games are closer - reduce extreme predictions
    if abs(predicted_margin) > 10:
        # Regress toward pick'em by ~20%
        adjustment = -0.2 * predicted_margin
        return round(adjustment, 1), f"Rivalry game (regress {adjustment:+.1f})"
    elif abs(predicted_margin) > 5:
        adjustment = -0.1 * predicted_margin
        return round(adjustment, 1), f"Rivalry game (regress {adjustment:+.1f})"
    
    return 0.0, "Rivalry game"


if __name__ == "__main__":
    print("="*50)
    print("H2H / RIVALRY ADJUSTMENTS")
    print("="*50)
    
    print(f"\nTracking {len(RIVALRIES)} rivalry matchups")
    
    # Test cases
    tests = [
        ("Duke", "North Carolina", -8.0),
        ("Kansas", "Kansas St.", -15.0),
        ("Gonzaga", "Saint Mary's", -12.0),
        ("Kentucky", "Tennessee", 3.0),
        ("Santa Clara", "San Diego", -20.0),  # Not a rivalry
    ]
    
    print("\nTest cases:")
    print("-"*50)
    
    for home, away, margin in tests:
        rival = is_rivalry(home, away)
        adj, reason = get_rivalry_adjustment(home, away, margin)
        final = margin + adj
        
        print(f"\n{away} @ {home}")
        print(f"  Predicted: {margin:+.1f}")
        print(f"  Rivalry: {rival}")
        if adj != 0:
            print(f"  Adjustment: {adj:+.1f}")
            print(f"  Final: {final:+.1f}")
