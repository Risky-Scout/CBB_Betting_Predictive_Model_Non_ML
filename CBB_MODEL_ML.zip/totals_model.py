#!/usr/bin/env python3
"""
TOTALS (OVER/UNDER) MODEL - CALIBRATED
======================================
Calibrated against 5,025 historical games.
Average D1 total: 145.7 points
Standard deviation: 18.4 points
"""

import numpy as np
import os
from scipy import stats
from dataclasses import dataclass
from typing import List
from datetime import datetime, timezone

# Calibration constants (from historical data)
AVG_TOTAL = 145.7
TOTAL_STD = 18.4
SCALE_FACTOR = 0.91  # Correction factor for efficiency formula

@dataclass
class TotalsPrediction:
    home: str
    away: str
    predicted_total: float
    market_total: float
    edge: float
    bet_side: str
    confidence: float
    factors: List[str]
    
    @property
    def grade(self):
        if self.edge >= 6: return "A+"
        if self.edge >= 5: return "A"
        if self.edge >= 4: return "A-"
        if self.edge >= 3: return "B+"
        if self.edge >= 2: return "B"
        return "C"


class TotalsPredictor:
    """Calibrated totals predictor."""
    
    def __init__(self, team_loader):
        self.loader = team_loader
        self.rest_tracker = None
        
    def set_rest_tracker(self, rest):
        self.rest_tracker = rest
    
    def predict_total(self, home_name, away_name, market_total=None):
        home = self.loader.get(home_name)
        away = self.loader.get(away_name)
        
        if not home or not away:
            return None
        
        factors = []
        
        # CALIBRATED FORMULA
        # Step 1: Calculate expected tempo (possessions per game)
        game_tempo = (home['adj_t'] + away['adj_t']) / 2
        
        # Step 2: Calculate each team's expected points
        # Home points = (Home_AdjO * Away_AdjD / 100) * (tempo / 100)
        home_pts_raw = (home['adj_o'] * away['adj_d'] / 100) * (game_tempo / 100)
        away_pts_raw = (away['adj_o'] * home['adj_d'] / 100) * (game_tempo / 100)
        
        # Step 3: Apply calibration scale factor
        base_total = (home_pts_raw + away_pts_raw) * SCALE_FACTOR
        
        # Step 4: Adjustments
        adj = 0.0
        
        # Tempo extremes
        if game_tempo > 71:
            adj += 2.0
            factors.append(f"Fast pace ({game_tempo:.0f})")
        elif game_tempo < 64:
            adj -= 2.0
            factors.append(f"Slow pace ({game_tempo:.0f})")
        
        # Elite defense matchup
        min_def = min(home['adj_d'], away['adj_d'])
        max_def = max(home['adj_d'], away['adj_d'])
        
        if min_def < 92:
            adj -= 2.5
            factors.append(f"Elite D ({min_def:.0f})")
        elif min_def < 96:
            adj -= 1.0
        
        # Poor defense matchup
        if max_def > 112:
            adj += 2.5
            factors.append(f"Weak D ({max_def:.0f})")
        elif max_def > 108:
            adj += 1.0
        
        # Both defenses bad = shootout
        if home['adj_d'] > 105 and away['adj_d'] > 105:
            adj += 2.0
            factors.append("Both poor D")
        
        # Both defenses elite = grind
        if home['adj_d'] < 98 and away['adj_d'] < 98:
            adj -= 2.0
            factors.append("Both strong D")
        
        # Rest factor
        if self.rest_tracker:
            try:
                home_rest = self.rest_tracker.get_days_rest(home_name)
                away_rest = self.rest_tracker.get_days_rest(away_name)
                
                if home_rest == 1:  # B2B
                    adj -= 2.0
                    factors.append(f"{home['team'][:10]} B2B")
                if away_rest == 1:
                    adj -= 2.0
                    factors.append(f"{away['team'][:10]} B2B")
            except:
                pass
        
        # Blowout potential (slows game down)
        home_net = home['adj_o'] - home['adj_d']
        away_net = away['adj_o'] - away['adj_d']
        if abs(home_net - away_net) > 28:
            adj -= 2.0
            factors.append("Blowout risk")
        
        predicted_total = round(base_total + adj, 1)
        
        # Calculate edge and probabilities
        if market_total:
            edge = abs(predicted_total - market_total)
            
            if predicted_total > market_total:
                bet_side = "OVER"
                confidence = 1 - stats.norm.cdf(market_total, predicted_total, TOTAL_STD)
            else:
                bet_side = "UNDER"
                confidence = stats.norm.cdf(market_total, predicted_total, TOTAL_STD)
        else:
            edge = 0
            bet_side = "N/A"
            confidence = 0.5
        
        return TotalsPrediction(
            home=home['team'], away=away['team'],
            predicted_total=predicted_total, market_total=market_total or 0,
            edge=edge, bet_side=bet_side, confidence=confidence, factors=factors
        )


def fetch_totals_odds(api_key):
    """Fetch totals odds from Odds API."""
    import requests
    
    try:
        r = requests.get(
            "https://api.the-odds-api.com/v4/sports/basketball_ncaab/odds",
            params={'apiKey': api_key, 'regions': 'us', 'markets': 'totals'},
            timeout=30
        )
        if r.status_code != 200:
            return []
        
        now = datetime.now(timezone.utc)
        games = []
        
        for g in r.json():
            commence = g.get('commence_time', '')
            if commence:
                try:
                    game_time = datetime.fromisoformat(commence.replace('Z', '+00:00'))
                    if (game_time - now).total_seconds() / 3600 < 1.5:
                        continue
                except:
                    pass
            
            home = g.get('home_team', '')
            away = g.get('away_team', '')
            
            totals = []
            for b in g.get('bookmakers', []):
                for m in b.get('markets', []):
                    if m['key'] == 'totals':
                        for o in m['outcomes']:
                            if o['name'] == 'Over':
                                totals.append(o.get('point', 0))
            
            if totals:
                games.append({
                    'home': home,
                    'away': away,
                    'total': round(np.median(totals), 1)
                })
        
        return games
    except Exception as e:
        print(f"Error: {e}")
        return []


def run_totals_model(api_key, min_edge=3.0, max_bets=5):
    """Run the calibrated totals model."""
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    print("\n" + "="*70)
    print("TOTALS MODEL (CALIBRATED)")
    print("="*70)
    print(f"Calibration: {AVG_TOTAL:.1f} avg, {TOTAL_STD:.1f} std (5,025 games)")
    
    # Load teams
    from enhanced_betting_system_v7 import TeamLoader
    loader = TeamLoader()
    print("\n[1] Loading teams...")
    loader.load()
    
    # Load rest
    rest = None
    try:
        from data_fetchers import RestTrackerV2
        rest = RestTrackerV2()
        print("\n[2] Loading rest data...")
        rest.fetch_recent_games(5)
    except:
        print("\n[2] Rest data unavailable")
    
    # Create predictor
    predictor = TotalsPredictor(loader)
    if rest:
        predictor.set_rest_tracker(rest)
    
    # Fetch odds
    print("\n[3] Fetching totals odds...")
    games = fetch_totals_odds(api_key)
    print(f"  ✓ {len(games)} games")
    
    # Map names
    try:
        from team_mapping import TeamMapper
        mapper = TeamMapper()
        for g in games:
            g['home'] = mapper.odds_to_barttorvik(g['home'])
            g['away'] = mapper.odds_to_barttorvik(g['away'])
    except:
        pass
    
    # Predict
    print("\n[4] Generating predictions...")
    bets = []
    for g in games:
        pred = predictor.predict_total(g['home'], g['away'], g['total'])
        if pred and pred.edge >= min_edge:
            bets.append(pred)
    
    bets.sort(key=lambda x: x.edge, reverse=True)
    bets = bets[:max_bets]
    
    # Output
    print("\n" + "="*70)
    print("TOTALS BETS")
    print("="*70)
    
    if not bets:
        print("\n  No qualifying totals bets (3+ edge)")
        return []
    
    for i, b in enumerate(bets, 1):
        print(f"\n{'-'*70}")
        print(f"#{i}: {b.away} @ {b.home}")
        print(f"{'-'*70}")
        print(f"  BET:    {b.bet_side} {b.market_total}")
        print(f"  Model:  {b.predicted_total}")
        print(f"  Edge:   {b.edge:.1f} pts | Conf: {b.confidence*100:.0f}%")
        print(f"  Grade:  {b.grade}")
        if b.factors:
            print(f"  Factors: {', '.join(b.factors)}")
    
    # Summary
    print(f"\n{'='*70}")
    print("QUICK REFERENCE")
    print(f"{'='*70}")
    print(f"{'#':<2} {'Game':<28} {'Bet':<12} {'Model':>6} {'Edge':>5} {'Conf':>5}")
    print("-"*60)
    for i, b in enumerate(bets, 1):
        game = f"{b.away[:12]}@{b.home[:12]}"
        bet = f"{b.bet_side} {b.market_total}"
        print(f"{i:<2} {game:<28} {bet:<12} {b.predicted_total:>6.1f} {b.edge:>5.1f} {b.confidence*100:>4.0f}%")
    print("="*70)
    
    return bets


if __name__ == "__main__":
    import sys
    api_key = sys.argv[1] if len(sys.argv) > 1 else "da45cdad6addfa18598c567d02ccd848"
    run_totals_model(api_key)
