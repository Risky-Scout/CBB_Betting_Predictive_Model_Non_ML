#!/usr/bin/env python3
"""
PUBLIC BETTING PERCENTAGE
=========================
Contrarian edge: fade the public when >70% on one side.

Data sources (in order of preference):
1. Action Network API (paid)
2. Manual entry from free sites
3. Simulated based on line movement (fallback)

Research shows:
- Teams getting <30% of bets cover ~53-54%
- Teams getting >70% of bets cover ~47-48%
- Sweet spot: Bet against public when >70% AND you have edge
"""

import os
import json
from datetime import datetime

class PublicBetting:
    """Track and use public betting percentages."""
    
    def __init__(self):
        self.data = {}
        self.cache_path = os.path.expanduser("~/cbb_betting/public_betting_cache.json")
        self._load_cache()
    
    def _load_cache(self):
        """Load cached public betting data."""
        if os.path.exists(self.cache_path):
            try:
                with open(self.cache_path, 'r') as f:
                    self.data = json.load(f)
            except:
                self.data = {}
    
    def _save_cache(self):
        """Save public betting data to cache."""
        with open(self.cache_path, 'w') as f:
            json.dump(self.data, f, indent=2)
    
    def add_public_pct(self, game_key, home_pct, away_pct=None):
        """
        Add public betting percentage for a game.
        
        Args:
            game_key: "Away @ Home" format
            home_pct: Percentage of bets on home team (0-100)
            away_pct: Optional, calculated as 100 - home_pct
        """
        if away_pct is None:
            away_pct = 100 - home_pct
        
        self.data[game_key] = {
            'home_pct': home_pct,
            'away_pct': away_pct,
            'updated': datetime.now().isoformat()
        }
        self._save_cache()
    
    def get_public_pct(self, game_key):
        """Get public betting percentages for a game."""
        return self.data.get(game_key)
    
    def get_contrarian_adjustment(self, game_key, betting_home):
        """
        Get contrarian adjustment based on public betting.
        
        Args:
            game_key: "Away @ Home" format
            betting_home: True if betting home team
        
        Returns:
            (adjustment, reason)
            - Positive adjustment = increase confidence
            - Negative adjustment = decrease confidence
        """
        pct = self.get_public_pct(game_key)
        if not pct:
            return 0.0, None
        
        home_pct = pct['home_pct']
        away_pct = pct['away_pct']
        
        # Determine if we're fading or following the public
        if betting_home:
            public_on_your_side = home_pct
        else:
            public_on_your_side = away_pct
        
        adj = 0.0
        reason = None
        
        # Contrarian edge: public is heavily against you = good
        if public_on_your_side <= 25:
            adj = 0.15  # 15% Kelly boost
            reason = f"Strong contrarian ({public_on_your_side:.0f}% public)"
        elif public_on_your_side <= 35:
            adj = 0.10  # 10% boost
            reason = f"Contrarian ({public_on_your_side:.0f}% public)"
        elif public_on_your_side >= 75:
            adj = -0.10  # 10% reduction - you're with heavy public
            reason = f"Public heavy ({public_on_your_side:.0f}%)"
        elif public_on_your_side >= 65:
            adj = -0.05  # 5% reduction
            reason = f"Public leaning ({public_on_your_side:.0f}%)"
        
        return adj, reason
    
    def estimate_from_line_movement(self, opening_spread, current_spread, home_team):
        """
        Estimate public betting % from line movement.
        
        Theory: Lines move toward public money
        - If line moves toward home, public is on home
        - Sharps move lines opposite to public
        
        This is a ROUGH estimate, not as accurate as real data.
        """
        movement = current_spread - opening_spread
        
        # Positive movement = line moved toward away (home got more points)
        # This usually means public on away
        
        if abs(movement) < 0.5:
            return {'home_pct': 50, 'away_pct': 50, 'estimated': True}
        
        # Rough estimate: 1 point move ≈ 10% public shift
        shift = min(25, abs(movement) * 8)
        
        if movement > 0:
            # Line moved toward away favorite / home getting more points
            # Public likely on away
            return {'home_pct': 50 - shift, 'away_pct': 50 + shift, 'estimated': True}
        else:
            # Line moved toward home favorite
            # Public likely on home
            return {'home_pct': 50 + shift, 'away_pct': 50 - shift, 'estimated': True}
    
    def clear_cache(self):
        """Clear all cached data."""
        self.data = {}
        self._save_cache()


# Manual entry helper
def manual_entry():
    """Interactive mode to enter public betting percentages."""
    pb = PublicBetting()
    
    print("="*50)
    print("PUBLIC BETTING MANUAL ENTRY")
    print("="*50)
    print("Enter data from ActionNetwork, VegasInsider, etc.")
    print("Type 'done' when finished.\n")
    
    while True:
        game = input("Game (Away @ Home): ").strip()
        if game.lower() == 'done':
            break
        
        try:
            home_pct = float(input("Home team bet %: ").strip())
            pb.add_public_pct(game, home_pct)
            print(f"  ✓ Added: {game} - Home {home_pct:.0f}% / Away {100-home_pct:.0f}%\n")
        except:
            print("  ✗ Invalid input, try again\n")
    
    print(f"\n✓ Saved {len(pb.data)} games to cache")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'entry':
        manual_entry()
    else:
        print("PUBLIC BETTING MODULE")
        print("="*50)
        
        pb = PublicBetting()
        
        # Test with sample data
        pb.add_public_pct("San Diego @ Santa Clara", 25)  # 25% on home
        pb.add_public_pct("Seattle @ Saint Mary's", 70)   # 70% on home
        pb.add_public_pct("Boise St. @ San Diego St.", 45)  # 45% on home
        
        print("\nTest contrarian adjustments:")
        tests = [
            ("San Diego @ Santa Clara", True, "Betting Santa Clara (home)"),
            ("San Diego @ Santa Clara", False, "Betting San Diego (away)"),
            ("Seattle @ Saint Mary's", True, "Betting Saint Mary's (home)"),
            ("Boise St. @ San Diego St.", True, "Betting San Diego St. (home)"),
        ]
        
        for game, is_home, desc in tests:
            adj, reason = pb.get_contrarian_adjustment(game, is_home)
            pct = pb.get_public_pct(game)
            print(f"\n  {desc}")
            print(f"    Public: Home {pct['home_pct']}% / Away {pct['away_pct']}%")
            print(f"    Adjustment: {adj:+.0%} Kelly")
            if reason:
                print(f"    Reason: {reason}")
        
        print("\n\nTo manually enter public betting data:")
        print("  python3 ~/cbb_betting/public_betting.py entry")
