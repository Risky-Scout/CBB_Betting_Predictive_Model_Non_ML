#!/usr/bin/env python3
"""
PLAYER-LEVEL PROJECTIONS v4
===========================
Correct column mapping from Barttorvik CSV:
[0]=Player, [1]=Team, [3]=Games, [4]=MPG, [28]=BPM, [47]=ORtg, [48]=DRtg
"""

import requests
import os
import json
import re
from datetime import datetime

CACHE_PATH = os.path.expanduser("~/cbb_betting/player_stats.json")

class PlayerProjections:
    def __init__(self):
        self.players = {}
        
    def fetch_all_players(self):
        print("  Fetching Barttorvik player stats...")
        
        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'}
        url = "https://barttorvik.com/getadvstats.php?year=2026&csv=1"
        
        try:
            r = requests.get(url, headers=headers, timeout=30)
            if r.status_code != 200:
                print(f"  ✗ Failed: {r.status_code}")
                return self._load_cache()
            
            lines = r.text.strip().split('\n')
            print(f"  Found {len(lines)} player records")
            
            self.players = {}
            count = 0
            
            for line in lines:
                try:
                    # Handle quoted fields with commas inside
                    parts = []
                    current = ""
                    in_quotes = False
                    
                    for char in line:
                        if char == '"':
                            in_quotes = not in_quotes
                        elif char == ',' and not in_quotes:
                            parts.append(current.strip().strip('"'))
                            current = ""
                        else:
                            current += char
                    parts.append(current.strip().strip('"'))
                    
                    if len(parts) < 30:
                        continue
                    
                    player = parts[0].strip('"')
                    team = parts[1].strip('"')
                    
                    # Games played
                    try:
                        games = int(float(parts[3])) if parts[3] else 0
                    except:
                        games = 0
                    
                    # MPG - column 4
                    try:
                        mpg = float(parts[4]) if parts[4] else 0
                    except:
                        mpg = 0
                    
                    # BPM - column 28
                    try:
                        bpm = float(parts[28]) if parts[28] else 0
                    except:
                        bpm = 0
                    
                    # Only include rotation players (>10 MPG, >3 games)
                    if player and team and mpg > 10 and games > 3:
                        team_key = team.lower()
                        if team_key not in self.players:
                            self.players[team_key] = []
                        
                        self.players[team_key].append({
                            'name': player,
                            'mpg': round(mpg, 1),
                            'bpm': round(bpm, 2),
                            'games': games
                        })
                        count += 1
                        
                except Exception as e:
                    continue
            
            # Sort by MPG
            for team in self.players:
                self.players[team] = sorted(self.players[team], key=lambda x: x['mpg'], reverse=True)
            
            self._save_cache()
            print(f"  ✓ Loaded {count} players for {len(self.players)} teams")
            return True
            
        except Exception as e:
            print(f"  ✗ Error: {e}")
            return self._load_cache()
    
    def _save_cache(self):
        try:
            with open(CACHE_PATH, 'w') as f:
                json.dump({'updated': datetime.now().isoformat(), 'players': self.players}, f)
        except:
            pass
    
    def _load_cache(self):
        if os.path.exists(CACHE_PATH):
            try:
                with open(CACHE_PATH) as f:
                    data = json.load(f)
                    self.players = data.get('players', {})
                print(f"  ✓ Loaded {sum(len(v) for v in self.players.values())} players from cache")
                return True
            except:
                pass
        return False
    
    def get_player_impact(self, team, player_name):
        """
        Impact = |BPM| × (MPG/40) × Replacement_Factor
        
        High BPM players (stars): BPM > 5 → Impact 3-6 pts
        Average starters: BPM 0-5 → Impact 1-3 pts  
        Role players: BPM < 0 → Impact 0.5-1.5 pts
        """
        team_key = team.lower().strip()
        
        # Find team (fuzzy)
        if team_key not in self.players:
            for k in self.players:
                if team_key in k or k in team_key:
                    team_key = k
                    break
            else:
                return 2.0  # Default
        
        # Find player (fuzzy)
        player_lower = player_name.lower().strip()
        player_parts = player_lower.split()
        last_name = player_parts[-1] if player_parts else ""
        first_name = player_parts[0] if player_parts else ""
        
        for p in self.players.get(team_key, []):
            p_name = p['name'].lower()
            
            if (player_lower in p_name or 
                p_name in player_lower or
                (last_name and last_name in p_name) or
                (first_name and len(first_name) > 2 and first_name in p_name)):
                
                mpg = p['mpg']
                bpm = p['bpm']
                
                # Impact formula:
                # Base = |BPM| × (MPG/40)
                # Then scale: stars have bigger impact
                
                minutes_share = mpg / 40.0
                
                if bpm >= 5:
                    # Star player
                    impact = bpm * minutes_share * 1.0
                elif bpm >= 2:
                    # Good starter
                    impact = bpm * minutes_share * 0.9
                elif bpm >= 0:
                    # Average player
                    impact = max(1.5, bpm * minutes_share * 0.8 + 1.0)
                else:
                    # Below average - still matters if they play minutes
                    impact = max(1.0, (2.0 + bpm) * minutes_share * 0.7)
                
                # Clamp
                impact = max(0.5, min(6.0, impact))
                
                return round(impact, 1)
        
        return 2.0  # Default for unknown player
    
    def get_team_players(self, team):
        team_key = team.lower().strip()
        
        if team_key in self.players:
            return self.players[team_key]
        
        for k in self.players:
            if team_key in k or k in team_key:
                return self.players[k]
        
        return []
    
    def print_team(self, team):
        players = self.get_team_players(team)
        
        if not players:
            print(f"  {team}: No data")
            return
        
        print(f"\n  {team.upper()}:")
        print(f"  {'Player':<25} {'MPG':>6} {'BPM':>7} {'Games':>6} {'Impact':>7}")
        print(f"  {'-'*55}")
        
        for p in players[:10]:
            impact = self.get_player_impact(team, p['name'])
            print(f"  {p['name']:<25} {p['mpg']:>6.1f} {p['bpm']:>+7.2f} {p['games']:>6} {impact:>7.1f}")


class EnhancedInjuryLoader:
    """Combines injuries with player-level BPM for precise impact."""
    
    def __init__(self, injury_loader, player_projections):
        self.injuries = injury_loader
        self.players = player_projections
    
    def get_injury_impact(self, team):
        if not self.injuries:
            return 0.0, []
        
        team_injuries = self.injuries.get_team_injuries(team)
        if not team_injuries:
            return 0.0, []
        
        total = 0.0
        details = []
        
        for inj in team_injuries:
            status = inj.get('status', '').upper()
            name = inj.get('player', '')
            
            base = self.players.get_player_impact(team, name)
            
            if 'OUT' in status:
                impact = base * 1.0
                details.append(f"{name} OUT ({impact:.1f} pts)")
            elif 'DOUBT' in status:
                impact = base * 0.75
                details.append(f"{name} DOUBT ({impact:.1f} pts)")
            elif 'GTD' in status or 'GAME TIME' in status:
                impact = base * 0.5
                details.append(f"{name} GTD ({impact:.1f} pts)")
            elif 'QUESTION' in status:
                impact = base * 0.25
            else:
                impact = base * 0.5
            
            total += impact
        
        return round(total, 1), details[:5]


if __name__ == "__main__":
    print("="*70)
    print("PLAYER PROJECTIONS v4")
    print("="*70)
    
    proj = PlayerProjections()
    proj.fetch_all_players()
    
    # Show key teams
    for team in ['Duke', 'Kansas', 'Kentucky', 'California', 'Notre Dame', 'Michigan', 'Auburn', 'Houston']:
        proj.print_team(team)
    
    print("\n" + "="*70)
    print("ENHANCED INJURY IMPACT (with player-level BPM)")
    print("="*70)
    
    try:
        from injury_loader import InjuryLoader
        inj = InjuryLoader()
        inj.load()
        
        enhanced = EnhancedInjuryLoader(inj, proj)
        
        for team in ['California', 'Notre Dame', 'Washington St.', 'Louisville', 'Maryland', 'Oregon']:
            impact, players = enhanced.get_injury_impact(team)
            print(f"\n  {team}: {impact:.1f} pts total injury impact")
            for p in players:
                print(f"    • {p}")
    except Exception as e:
        print(f"  Error: {e}")
