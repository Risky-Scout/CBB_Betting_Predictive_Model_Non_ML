#!/usr/bin/env python3
"""
LINE MOVEMENT TRACKER
=====================
Captures opening lines, tracks movement, identifies sharp action.
Steam moves toward your side = confirmation of edge.
"""

import requests
import os
import json
from datetime import datetime, timedelta
import time

CACHE_PATH = os.path.expanduser("~/cbb_betting/line_history.json")

class LineMovementTracker:
    """Track line movements and identify sharp money."""
    
    def __init__(self, odds_api_key):
        self.api_key = odds_api_key
        self.line_history = {}  # game_key -> [{timestamp, spread}, ...]
        self._load_cache()
    
    def _load_cache(self):
        if os.path.exists(CACHE_PATH):
            try:
                with open(CACHE_PATH) as f:
                    self.line_history = json.load(f)
            except:
                self.line_history = {}
    
    def _save_cache(self):
        with open(CACHE_PATH, 'w') as f:
            json.dump(self.line_history, f, indent=2)
    
    def fetch_current_lines(self):
        """Fetch current lines and record timestamp."""
        url = "https://api.the-odds-api.com/v4/sports/basketball_ncaab/odds"
        params = {
            'apiKey': self.api_key,
            'regions': 'us',
            'markets': 'spreads'
        }
        
        try:
            r = requests.get(url, params=params, timeout=30)
            if r.status_code != 200:
                return None
            
            timestamp = datetime.now().isoformat()
            games = []
            
            for g in r.json():
                home = g.get('home_team', '')
                away = g.get('away_team', '')
                game_key = f"{away} @ {home}"
                
                spreads = {}
                for book in g.get('bookmakers', []):
                    book_name = book.get('key', '')
                    for market in book.get('markets', []):
                        if market['key'] == 'spreads':
                            for outcome in market['outcomes']:
                                if outcome['name'] == home:
                                    spreads[book_name] = outcome.get('point', 0)
                
                if spreads:
                    median_spread = sorted(spreads.values())[len(spreads)//2]
                    
                    # Record in history
                    if game_key not in self.line_history:
                        self.line_history[game_key] = []
                    
                    self.line_history[game_key].append({
                        'timestamp': timestamp,
                        'spread': median_spread,
                        'by_book': spreads
                    })
                    
                    games.append({
                        'game': game_key,
                        'home': home,
                        'away': away,
                        'spread': median_spread,
                        'spreads_by_book': spreads
                    })
            
            self._save_cache()
            return games
            
        except Exception as e:
            print(f"  Error fetching lines: {e}")
            return None
    
    def get_line_movement(self, game_key):
        """Get line movement history for a game."""
        if game_key not in self.line_history:
            return None
        
        history = self.line_history[game_key]
        if len(history) < 2:
            return {
                'opening': history[0]['spread'] if history else None,
                'current': history[-1]['spread'] if history else None,
                'movement': 0,
                'readings': len(history)
            }
        
        opening = history[0]['spread']
        current = history[-1]['spread']
        movement = current - opening
        
        return {
            'opening': opening,
            'current': current,
            'movement': movement,
            'direction': 'toward home' if movement < 0 else 'toward away' if movement > 0 else 'no movement',
            'readings': len(history),
            'history': [(h['timestamp'], h['spread']) for h in history]
        }
    
    def identify_sharp_moves(self, min_movement=1.5):
        """
        Identify games with significant line movement (sharp action).
        
        Sharp moves typically:
        - Move against public betting
        - Happen quickly after open
        - Are 1.5+ points
        """
        sharp_games = []
        
        for game_key, history in self.line_history.items():
            if len(history) < 2:
                continue
            
            movement = self.get_line_movement(game_key)
            if movement and abs(movement['movement']) >= min_movement:
                sharp_games.append({
                    'game': game_key,
                    'opening': movement['opening'],
                    'current': movement['current'],
                    'movement': movement['movement'],
                    'direction': movement['direction']
                })
        
        return sorted(sharp_games, key=lambda x: abs(x['movement']), reverse=True)
    
    def check_reverse_line_movement(self, game_key, public_side='home'):
        """
        Reverse Line Movement (RLM) = line moves opposite to public betting.
        This indicates sharp money on the other side.
        
        Example: 70% public on Home -3, but line moves to Home -2.5
        → Sharp money on Away
        """
        movement = self.get_line_movement(game_key)
        if not movement:
            return None
        
        move = movement['movement']
        
        # Positive movement = line moved toward away (home spread got worse)
        # Negative movement = line moved toward home (home spread got better)
        
        if public_side == 'home' and move > 0.5:
            return {
                'rlm_detected': True,
                'sharp_side': 'away',
                'explanation': f"Public on home but line moved {move:+.1f} toward away"
            }
        elif public_side == 'away' and move < -0.5:
            return {
                'rlm_detected': True,
                'sharp_side': 'home',
                'explanation': f"Public on away but line moved {move:+.1f} toward home"
            }
        
        return {'rlm_detected': False}
    
    def get_steam_move_alert(self, game_key, your_side):
        """
        Check if line is moving toward or away from your bet.
        
        Steam toward your side = confirmation
        Steam away from your side = concern
        """
        movement = self.get_line_movement(game_key)
        if not movement or movement['movement'] == 0:
            return None
        
        move = movement['movement']
        
        # Determine if movement helps or hurts your bet
        if your_side == 'home':
            if move < -0.5:  # Line moved toward home
                return {
                    'alert': 'POSITIVE',
                    'message': f"Line moving your way ({move:+.1f}). Sharp money confirming."
                }
            elif move > 0.5:
                return {
                    'alert': 'NEGATIVE', 
                    'message': f"Line moving against you ({move:+.1f}). Consider reducing stake."
                }
        else:  # your_side == 'away'
            if move > 0.5:
                return {
                    'alert': 'POSITIVE',
                    'message': f"Line moving your way ({move:+.1f}). Sharp money confirming."
                }
            elif move < -0.5:
                return {
                    'alert': 'NEGATIVE',
                    'message': f"Line moving against you ({move:+.1f}). Consider reducing stake."
                }
        
        return {'alert': 'NEUTRAL', 'message': 'Minimal line movement'}
    
    def print_report(self):
        """Print line movement report."""
        print("\n" + "="*70)
        print("LINE MOVEMENT REPORT")
        print("="*70)
        
        sharp = self.identify_sharp_moves(1.0)
        
        if not sharp:
            print("\n  No significant line movements detected")
            return
        
        print(f"\n  SIGNIFICANT MOVES (1+ points):")
        print(f"  {'-'*65}")
        print(f"  {'Game':<40} {'Open':>8} {'Curr':>8} {'Move':>8}")
        print(f"  {'-'*65}")
        
        for g in sharp[:15]:
            game = g['game'][:38]
            print(f"  {game:<40} {g['opening']:>+8.1f} {g['current']:>+8.1f} {g['movement']:>+8.1f}")
        
        print(f"  {'-'*65}")


class LineMovementIntegration:
    """Integrate line movement into betting decisions."""
    
    def __init__(self, tracker):
        self.tracker = tracker
    
    def adjust_confidence(self, prediction, movement_data):
        """
        Adjust bet confidence based on line movement.
        
        Returns multiplier: >1 = increase stake, <1 = decrease stake
        """
        if not movement_data:
            return 1.0
        
        move = movement_data.get('movement', 0)
        your_side = 'home' if prediction.bet_team == prediction.home else 'away'
        
        # Line moving toward your side = confirmation
        if your_side == 'home' and move < -1.0:
            return 1.15  # Increase stake 15%
        elif your_side == 'away' and move > 1.0:
            return 1.15
        
        # Line moving against you = reduce confidence
        elif your_side == 'home' and move > 1.0:
            return 0.85  # Reduce stake 15%
        elif your_side == 'away' and move < -1.0:
            return 0.85
        
        return 1.0
    
    def get_line_value(self, prediction, movement_data):
        """
        Determine if you're getting good line value.
        
        If line opened at -3 and you bet at -5, you got bad value.
        If line opened at -5 and you bet at -3, you got good value.
        """
        if not movement_data:
            return None
        
        opening = movement_data.get('opening')
        current = movement_data.get('current')
        
        if opening is None or current is None:
            return None
        
        your_line = prediction.bet_line
        
        # Compare your line to opening
        if prediction.bet_team == prediction.home:
            value = your_line - opening  # Positive = you got better number
        else:
            value = opening - your_line  # For away, flip the comparison
        
        return {
            'opening': opening,
            'your_line': your_line,
            'current': current,
            'value_vs_open': round(value, 1),
            'assessment': 'Good value' if value > 0.5 else 'Bad value' if value < -0.5 else 'Fair value'
        }


if __name__ == "__main__":
    import sys
    
    # Get API key
    api_key = "da45cdad6addfa18598c567d02ccd848"
    
    tracker = LineMovementTracker(api_key)
    
    print("Fetching current lines...")
    games = tracker.fetch_current_lines()
    
    if games:
        print(f"  ✓ Captured lines for {len(games)} games")
    
    tracker.print_report()
    
    # Show sample game movement
    if tracker.line_history:
        sample_game = list(tracker.line_history.keys())[0]
        print(f"\n  Sample game: {sample_game}")
        movement = tracker.get_line_movement(sample_game)
        if movement:
            print(f"  Opening: {movement['opening']}")
            print(f"  Current: {movement['current']}")
            print(f"  Movement: {movement['movement']:+.1f}")
