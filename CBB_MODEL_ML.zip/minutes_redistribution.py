#!/usr/bin/env python3
"""
PLAYER MINUTES REDISTRIBUTION
=============================
When a starter is OUT, project how minutes redistribute to backups.
Recalculate team efficiency with new rotation.
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class MinutesRedistributor:
    """
    Projects team efficiency changes when players are out.
    
    Key insight: When a star is OUT, the replacement player is worse.
    The team loses not just the star's production, but gets negative
    production from the replacement.
    """
    
    def __init__(self, player_projections):
        self.players = player_projections
    
    def get_rotation(self, team):
        """Get team's rotation sorted by minutes."""
        return self.players.get_team_players(team)
    
    def calculate_replacement_impact(self, team, out_players):
        """
        Calculate total impact when specific players are out.
        
        Formula:
        Impact = Σ (OUT_player_BPM - Replacement_BPM) × (OUT_player_MPG / 40)
        
        The replacement is typically the next man up in the rotation.
        """
        rotation = self.get_rotation(team)
        
        if not rotation:
            return 0.0, []
        
        total_impact = 0.0
        details = []
        
        # Find indices of out players
        out_indices = []
        out_names_lower = [p.lower() for p in out_players]
        
        for i, player in enumerate(rotation):
            if any(out in player['name'].lower() or player['name'].lower() in out 
                   for out in out_names_lower):
                out_indices.append(i)
        
        # For each out player, find their replacement
        for idx in out_indices:
            out_player = rotation[idx]
            out_mpg = out_player['mpg']
            out_bpm = out_player['bpm']
            
            # Find replacement (next available player not already playing heavy minutes)
            replacement = None
            replacement_bpm = -2.0  # Default: replacement is below average
            
            # Look for first player after the out player who isn't also out
            for j in range(idx + 1, len(rotation)):
                if j not in out_indices:
                    replacement = rotation[j]
                    replacement_bpm = replacement['bpm']
                    break
            
            # If no replacement found in rotation, use generic bench player
            if replacement is None:
                replacement_bpm = -2.0  # Below average bench player
            
            # Impact = (star's value - replacement's value) × minutes share
            bpm_diff = out_bpm - replacement_bpm
            minutes_share = out_mpg / 40.0
            
            # Scale factor: higher minute players have bigger impact
            impact = bpm_diff * minutes_share * 1.2  # 1.2 multiplier for cascading effects
            impact = max(0.5, min(7.0, impact))  # Clamp
            
            details.append({
                'out': out_player['name'],
                'out_bpm': out_bpm,
                'out_mpg': out_mpg,
                'replacement': replacement['name'] if replacement else 'Bench',
                'replacement_bpm': replacement_bpm,
                'impact': round(impact, 1)
            })
            
            total_impact += impact
        
        return round(total_impact, 1), details
    
    def simulate_rotation_change(self, team, out_players):
        """
        Simulate new rotation efficiency with players out.
        
        Returns adjusted team offensive and defensive ratings.
        """
        rotation = self.get_rotation(team)
        
        if not rotation:
            return None
        
        # Calculate team totals with full rotation
        total_minutes = sum(p['mpg'] for p in rotation[:10])
        weighted_bpm = sum(p['bpm'] * p['mpg'] for p in rotation[:10]) / total_minutes if total_minutes > 0 else 0
        
        # Remove out players and recalculate
        out_names_lower = [p.lower() for p in out_players]
        active_rotation = [p for p in rotation 
                          if not any(out in p['name'].lower() or p['name'].lower() in out 
                                    for out in out_names_lower)]
        
        if not active_rotation:
            return None
        
        # Redistribute minutes to remaining players
        out_minutes = sum(p['mpg'] for p in rotation[:10] 
                         if any(out in p['name'].lower() or p['name'].lower() in out 
                               for out in out_names_lower))
        
        # Add bench players if needed
        minutes_per_extra = out_minutes / max(1, len(active_rotation[:8]))
        
        new_total_minutes = total_minutes
        new_weighted_bpm = sum(p['bpm'] * (p['mpg'] + minutes_per_extra) 
                               for p in active_rotation[:8]) / new_total_minutes if new_total_minutes > 0 else 0
        
        bpm_change = new_weighted_bpm - weighted_bpm
        
        # Convert BPM change to point spread impact
        # BPM is per 100 possessions, game is ~70 possessions
        point_impact = bpm_change * 0.7
        
        return {
            'original_team_bpm': round(weighted_bpm, 2),
            'new_team_bpm': round(new_weighted_bpm, 2),
            'bpm_change': round(bpm_change, 2),
            'point_impact': round(point_impact, 1)
        }
    
    def print_analysis(self, team, out_players):
        """Print detailed analysis of rotation impact."""
        print(f"\n{'='*60}")
        print(f"ROTATION ANALYSIS: {team}")
        print(f"Out: {', '.join(out_players)}")
        print(f"{'='*60}")
        
        impact, details = self.calculate_replacement_impact(team, out_players)
        
        print(f"\n  PLAYER REPLACEMENTS:")
        print(f"  {'-'*55}")
        print(f"  {'Out Player':<20} {'BPM':>6} {'MPG':>6} → {'Replacement':<15} {'Impact':>7}")
        print(f"  {'-'*55}")
        
        for d in details:
            print(f"  {d['out']:<20} {d['out_bpm']:>+6.1f} {d['out_mpg']:>6.1f} → {d['replacement']:<15} {d['impact']:>+7.1f}")
        
        print(f"  {'-'*55}")
        print(f"  {'TOTAL IMPACT:':<50} {impact:>+7.1f} pts")
        
        sim = self.simulate_rotation_change(team, out_players)
        if sim:
            print(f"\n  TEAM BPM CHANGE:")
            print(f"  Original: {sim['original_team_bpm']:+.2f}")
            print(f"  With outs: {sim['new_team_bpm']:+.2f}")
            print(f"  Change: {sim['bpm_change']:+.2f} ({sim['point_impact']:+.1f} pts)")


class EnhancedInjuryImpact:
    """
    Combines injury data with minutes redistribution for precise impact.
    """
    
    def __init__(self, injury_loader, player_projections):
        self.injuries = injury_loader
        self.players = player_projections
        self.redistributor = MinutesRedistributor(player_projections)
    
    def get_injury_impact(self, team):
        """
        Calculate injury impact using minutes redistribution model.
        """
        if not self.injuries:
            return 0.0, []
        
        team_injuries = self.injuries.get_team_injuries(team)
        if not team_injuries:
            return 0.0, []
        
        # Get list of OUT players
        out_players = []
        gtd_players = []
        
        for inj in team_injuries:
            status = inj.get('status', '').upper()
            name = inj.get('player', '')
            
            if 'OUT' in status or 'DOUBT' in status:
                out_players.append(name)
            elif 'GTD' in status:
                gtd_players.append(name)
        
        # Calculate impact for OUT players
        out_impact, out_details = self.redistributor.calculate_replacement_impact(team, out_players)
        
        # GTD players at 50% probability
        gtd_impact, gtd_details = self.redistributor.calculate_replacement_impact(team, gtd_players)
        gtd_impact *= 0.5
        
        total_impact = out_impact + gtd_impact
        
        # Format details
        details = []
        for d in out_details:
            details.append(f"{d['out']} OUT ({d['impact']:.1f} pts) → {d['replacement']}")
        for d in gtd_details:
            details.append(f"{d['out']} GTD ({d['impact']*0.5:.1f} pts)")
        
        return round(total_impact, 1), details[:5]


if __name__ == "__main__":
    # Test with player data
    try:
        from player_projections import PlayerProjections
        from injury_loader import InjuryLoader
        
        print("Loading player data...")
        pp = PlayerProjections()
        pp.fetch_all_players()
        
        print("\nLoading injuries...")
        inj = InjuryLoader()
        inj.load()
        
        # Create redistributor
        mr = MinutesRedistributor(pp)
        
        # Test cases
        test_cases = [
            ('Notre Dame', ['Markus Burton']),
            ('Duke', ['Cameron Boozer']),
            ('Oregon', ['Jackson Shelstad']),
            ('California', ['Andrej Stojakovic', 'DJ Campbell']),
        ]
        
        for team, out in test_cases:
            mr.print_analysis(team, out)
        
        # Test enhanced injury impact
        print("\n" + "="*60)
        print("ENHANCED INJURY IMPACT (with redistribution)")
        print("="*60)
        
        enhanced = EnhancedInjuryImpact(inj, pp)
        
        for team in ['Notre Dame', 'California', 'Oregon', 'Louisville', 'Washington St.']:
            impact, details = enhanced.get_injury_impact(team)
            print(f"\n  {team}: {impact:.1f} pts")
            for d in details:
                print(f"    • {d}")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
