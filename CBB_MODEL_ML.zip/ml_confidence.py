#!/usr/bin/env python3
"""
ML CONFIDENCE LAYER
===================
Adjusts Kelly stake based on ML-predicted cover probability.
Does NOT change picks - only adjusts bet sizing.

Falls back gracefully if ML fails.
"""

import os
import pickle
import pandas as pd
import numpy as np

class MLConfidence:
    """ML-based confidence adjustment for bet sizing."""
    
    def __init__(self):
        self.model = None
        self.features = None
        self.loaded = False
        self._load_model()
    
    def _load_model(self):
        """Load the trained ML model."""
        try:
            model_path = os.path.expanduser("~/cbb_betting/ml_confidence_model.pkl")
            features_path = os.path.expanduser("~/cbb_betting/ml_features.txt")
            
            if not os.path.exists(model_path):
                print("  ⚠ ML model not found - using base model only")
                return
            
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            
            with open(features_path, 'r') as f:
                self.features = f.read().strip().split('\n')
            
            self.loaded = True
            print(f"  ✓ ML confidence model loaded")
        except Exception as e:
            print(f"  ⚠ ML model load failed: {e}")
            self.loaded = False
    
    def get_ml_confidence(self, predicted_margin, home_team_oe, home_team_de, is_home_bet):
        """
        Get ML-adjusted confidence for a bet.
        
        Args:
            predicted_margin: Model's predicted margin (positive = home favored)
            home_team_oe: Home team's offensive efficiency
            home_team_de: Home team's defensive efficiency
            is_home_bet: True if betting on home team
        
        Returns:
            ml_multiplier: Multiply Kelly stake by this (0.5 to 1.5)
            ml_cover_prob: ML's predicted cover probability
        """
        if not self.loaded or self.model is None:
            return 1.0, None  # No adjustment
        
        try:
            # Build features
            pred_margin_abs = abs(predicted_margin)
            home_favored = 1 if predicted_margin > 0 else 0
            eff_diff = home_team_oe - home_team_de
            
            X = pd.DataFrame([[
                predicted_margin,
                pred_margin_abs,
                home_favored,
                eff_diff
            ]], columns=self.features)
            
            # Get probability
            prob = self.model.predict_proba(X)[0]
            
            # prob[1] = probability home covers
            # If betting home, we want high prob[1]
            # If betting away, we want low prob[1] (high prob[0])
            if is_home_bet:
                cover_prob = prob[1]
            else:
                cover_prob = prob[0]
            
            # Convert to Kelly multiplier
            # Base assumption: 50% cover = 1.0 multiplier
            # Higher confidence = higher multiplier (capped)
            if cover_prob >= 0.70:
                multiplier = 1.3  # High confidence
            elif cover_prob >= 0.60:
                multiplier = 1.15  # Medium-high
            elif cover_prob >= 0.55:
                multiplier = 1.0  # Normal
            elif cover_prob >= 0.50:
                multiplier = 0.85  # Slightly reduce
            else:
                multiplier = 0.7  # Low confidence - reduce exposure
            
            return multiplier, cover_prob
            
        except Exception as e:
            # Fail gracefully
            return 1.0, None
    
    def get_edge_tier_stats(self):
        """Return historical stats by edge tier for display."""
        return {
            '0-2': {'cover': 57.2, 'games': 916},
            '2-4': {'cover': 60.8, 'games': 957},
            '4-6': {'cover': 67.3, 'games': 817},
            '6-8': {'cover': 69.7, 'games': 684},
            '8-10': {'cover': 74.5, 'games': 541},
            '10-15': {'cover': 83.0, 'games': 788},
            '15+': {'cover': 92.1, 'games': 318},
        }


if __name__ == "__main__":
    print("Testing ML Confidence Layer")
    print("="*50)
    
    ml = MLConfidence()
    
    if ml.loaded:
        # Test cases
        tests = [
            (5.0, 115.0, 100.0, True, "Home -5, good efficiency"),
            (-3.0, 100.0, 105.0, False, "Away +3, bad home team"),
            (12.0, 120.0, 95.0, True, "Home -12, elite home team"),
            (2.0, 105.0, 108.0, True, "Home -2, close game"),
        ]
        
        print("\nTest predictions:")
        for pred_margin, oe, de, is_home, desc in tests:
            mult, prob = ml.get_ml_confidence(pred_margin, oe, de, is_home)
            print(f"\n  {desc}")
            print(f"    ML Cover Prob: {prob*100:.1f}%" if prob else "    ML Cover Prob: N/A")
            print(f"    Kelly Multiplier: {mult:.2f}x")
        
        print("\n\nHistorical Edge Tiers:")
        for tier, stats in ml.get_edge_tier_stats().items():
            print(f"  {tier} pts: {stats['cover']:.1f}% cover ({stats['games']} games)")
